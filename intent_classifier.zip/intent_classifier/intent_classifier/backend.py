"""Model backends. The engine only sees `Question` in and `Answer` out, so any System One model can be plugged in."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol

from .config import BackendConfig


@dataclass(frozen=True)
class Question:
    type: Literal["noul", "choice", "score"]
    instructions: str
    options: dict[str, str] | list[str] | None = None


@dataclass
class Answer:
    type: str
    value: Any                                    # choice: option name, noul: P(yes), score: expected position
    probabilities: dict[str, float] = field(default_factory=dict)
    confidence: float | None = None               # the model's own confidence figure


@dataclass
class Decision:
    answers: dict[str, Answer]
    model: str
    latency_ms: float


class BackendUnavailable(RuntimeError):
    """The model server could not be reached (not started, wrong base_url, network down)."""


class Backend(Protocol):
    name: str
    def decide(self, state: str | dict, questions: dict[str, Question]) -> Decision: ...
    def close(self) -> None: ...


class TypeSafeBackend:
    """Hosted Jev or any TypeSafe-compatible server (Kev, Ollaya, ...), through the official SDK."""

    def __init__(self, cfg: BackendConfig):
        from typesafe_sdk import TypeSafeClient  # imported lazily so tests run without the SDK

        api_key = os.environ.get(cfg.api_key_env)
        if cfg.base_url and not api_key:
            api_key = "local"                     # local Kev without KEV_API_KEY accepts any key
        if not api_key:
            raise RuntimeError(f"set {cfg.api_key_env} to call hosted Jev")
        kwargs = {"api_key": api_key, "timeout": cfg.timeout_s}
        if cfg.base_url:
            kwargs["base_url"] = cfg.base_url
        if cfg.model:
            kwargs["model"] = cfg.model
        self._client = TypeSafeClient(**kwargs)
        self._url = cfg.base_url or "the TypeSafe API"
        self.name = f"{cfg.provider}:{cfg.model or 'default'}@{cfg.base_url or 'typesafe.ai'}"

    def decide(self, state, questions):
        import time

        from typesafe_sdk import Choice, Noul, Score, TypeSafeAPIConnectionError

        sdk_q = {}
        for key, q in questions.items():
            if q.type == "noul":
                sdk_q[key] = Noul(instructions=q.instructions)
            elif q.type == "choice":
                opts = q.options if isinstance(q.options, dict) else {o: None for o in q.options}
                sdk_q[key] = Choice(instructions=q.instructions, criteria={k: (v or None) for k, v in opts.items()})
            else:
                sdk_q[key] = Score(instructions=q.instructions, criteria=list(q.options))

        t = time.perf_counter()
        try:
            r = self._client.system_one(state=state, questions=sdk_q)
        except TypeSafeAPIConnectionError as e:
            raise BackendUnavailable(
                f"Cannot reach the model server at {self._url}. Start it (for local Kev: "
                f"python -m kev.serve --run jaredpalmer/kev-0.8b --port 8009) or fix backend.base_url in the config."
            ) from e
        ms = (time.perf_counter() - t) * 1000

        answers = {}
        for key, q in questions.items():
            if q.type == "noul":
                a = r.nouls[key]
                answers[key] = Answer("noul", a.noul, {"yes": a.noul, "no": 1 - a.noul}, None)
            elif q.type == "choice":
                a = r.choices[key]
                answers[key] = Answer("choice", a.choice, dict(a.probabilities), a.confidence)
            else:
                a = r.scores[key]
                probs = {str(q.options[int(i)]): p for i, p in a.probabilities.items()}
                answers[key] = Answer("score", a.score, probs, a.confidence)
        return Decision(answers, getattr(r, "model", self.name), ms)

    def close(self):
        self._client.close()


def make_backend(cfg: BackendConfig) -> Backend:
    return TypeSafeBackend(cfg)
