"""Turns a use-case config into System One questions, calls the backend and applies the decision policy."""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from .backend import Answer, Backend, Question, make_backend
from .config import Intent, UseCaseConfig


class Alternative(BaseModel):
    intent: str
    probability: float


class ClassificationResult(BaseModel):
    config: str
    intent: str                         # what the caller should act on (fallback when not confident)
    predicted_intent: str               # the model's top answer, before the policy
    confidence: float                   # probability of predicted_intent (product over levels when hierarchical)
    margin: float                       # top-1 minus top-2 probability at the leaf level
    needs_review: bool
    reason: str                         # why the policy decided what it did
    path: list[str] = Field(default_factory=list)          # [group, intent] for hierarchical configs
    alternatives: list[Alternative] = Field(default_factory=list)
    intents: list[Alternative] = Field(default_factory=list)  # multi-label: every intent above threshold
    extras: dict[str, Any] = Field(default_factory=dict)
    truncated: bool = False
    model: str = ""
    latency_ms: float = 0.0
    calls: int = 1


def option_text(intent: Intent, with_examples: bool = False) -> str:
    text = intent.description
    if with_examples and intent.examples:
        text += (" " if text else "") + "Examples: " + "; ".join(f'"{e}"' for e in intent.examples)
    return text


class IntentClassifier:
    def __init__(self, config: UseCaseConfig, backend: Backend | None = None):
        self.config = config
        self.backend = backend or make_backend(config.backend)
        self._extras = {k: Question(q.type, q.instructions, q.options) for k, q in config.extra_questions.items()}

    # ---- question building -------------------------------------------------------------------------------
    def _choice(self, intents: dict[str, Intent], instructions: str) -> Question:
        opts = {name: option_text(i, self.config.examples_in_options) for name, i in intents.items()}
        if self.config.add_fallback_option:
            opts[self.config.fallback_intent] = self.config.fallback_description
        return Question("choice", instructions, opts)

    def _state(self, text: str, context: dict | None) -> tuple[str | dict, bool]:
        limit = self.config.input.max_chars
        truncated = len(text) > limit
        text = text[:limit]
        static = self.config.input.context
        if not static and not context:
            return text, truncated
        state: dict[str, Any] = {"message": text}
        if static:
            state["background"] = static
        if context:
            state["context"] = context
        return state, truncated

    # ---- classification ----------------------------------------------------------------------------------
    def classify(self, text: str, context: dict | None = None) -> ClassificationResult:
        state, truncated = self._state(text, context)
        if self.config.mode == "multi":
            result = self._classify_multi(state)
        elif self.config.hierarchical:
            result = self._classify_hierarchical(state)
        else:
            result = self._classify_flat(state)
        result.truncated = truncated
        if truncated:
            result.reason += "; input truncated"
        return result

    def _classify_flat(self, state) -> ClassificationResult:
        questions = {"intent": self._choice(self.config.intents, self.config.instructions), **self._extras}
        d = self.backend.decide(state, questions)
        return self._single_result(d.answers["intent"], d.answers, [], 1.0, d.model, d.latency_ms, 1)

    def _classify_hierarchical(self, state) -> ClassificationResult:
        cfg = self.config
        groups = {n: Intent(description=i.description, examples=i.examples) for n, i in cfg.intents.items()}
        first = {"group": self._choice(groups, cfg.instructions), **self._extras}
        d1 = self.backend.decide(state, first)
        group = d1.answers["group"].value
        p_group = d1.answers["group"].probabilities.get(group, 0.0)
        node = cfg.intents.get(group)
        if node is None or not node.is_group:        # a leaf at the top level, or the fallback
            return self._single_result(d1.answers["group"], d1.answers, [group], 1.0, d1.model, d1.latency_ms, 1)
        second = {"intent": self._choice(node.children, f"{cfg.instructions} (The topic is: {group}.)")}
        d2 = self.backend.decide(state, second)
        return self._single_result(d2.answers["intent"], d1.answers, [group], p_group, d2.model,
                                   d1.latency_ms + d2.latency_ms, 2)

    def _single_result(self, ans: Answer, all_answers, path, p_parent, model, ms, calls) -> ClassificationResult:
        cfg, pol = self.config, self.config.policy
        ranked = sorted(ans.probabilities.items(), key=lambda kv: kv[1], reverse=True)
        top, p_top = ranked[0]
        margin = p_top - (ranked[1][1] if len(ranked) > 1 else 0.0)
        confidence = p_top * p_parent
        leaf = cfg.leaf_intents().get(top)
        threshold = leaf.min_confidence if leaf and leaf.min_confidence is not None else pol.min_confidence

        if top == cfg.fallback_intent:
            intent, review, reason = cfg.fallback_intent, True, "model chose the fallback option"
        elif confidence < threshold:
            intent, review, reason = cfg.fallback_intent, True, f"confidence {confidence:.2f} < {threshold:.2f}"
        elif margin < pol.min_margin:
            intent, review, reason = cfg.fallback_intent, True, f"margin {margin:.2f} < {pol.min_margin:.2f}"
        else:
            intent, review, reason = top, False, f"confidence {confidence:.2f} >= {threshold:.2f}"

        return ClassificationResult(
            config=cfg.name, intent=intent, predicted_intent=top, confidence=round(confidence, 4),
            margin=round(margin, 4), needs_review=review, reason=reason,
            path=[*path, top] if path and path[-1] != top else path or [top],
            alternatives=[Alternative(intent=k, probability=round(v, 4)) for k, v in ranked[: pol.top_k]],
            extras=self._extras_out(all_answers), model=model, latency_ms=round(ms, 1), calls=calls,
        )

    def _classify_multi(self, state) -> ClassificationResult:
        cfg, pol = self.config, self.config.policy
        leaves = cfg.leaf_intents()
        questions = {
            f"intent:{name}": Question(
                "noul", f"Does the message ask for or talk about '{name}'? {option_text(i, cfg.examples_in_options)}".strip())
            for name, i in leaves.items()
        }
        questions.update(self._extras)
        d = self.backend.decide(state, questions)
        probs = {name: d.answers[f"intent:{name}"].value for name in leaves}
        ranked = sorted(probs.items(), key=lambda kv: kv[1], reverse=True)
        present = [(k, p) for k, p in ranked if p >= (leaves[k].min_confidence or pol.multi_threshold)]
        top, p_top = ranked[0]
        # ambiguous = any intent sitting close to its threshold
        uncertain = [k for k, p in ranked if abs(p - (leaves[k].min_confidence or pol.multi_threshold)) < 0.15]
        if not present:
            intent, review, reason = cfg.fallback_intent, True, "no intent above threshold"
        elif uncertain:
            intent, review, reason = present[0][0], True, f"near threshold: {', '.join(uncertain)}"
        else:
            intent, review, reason = present[0][0], False, f"{len(present)} intent(s) above threshold"
        return ClassificationResult(
            config=cfg.name, intent=intent, predicted_intent=top, confidence=round(p_top, 4),
            margin=round(p_top - (ranked[1][1] if len(ranked) > 1 else 0.0), 4), needs_review=review,
            reason=reason, path=[top],
            alternatives=[Alternative(intent=k, probability=round(v, 4)) for k, v in ranked[: pol.top_k]],
            intents=[Alternative(intent=k, probability=round(v, 4)) for k, v in present],
            extras=self._extras_out(d.answers), model=d.model, latency_ms=round(d.latency_ms, 1), calls=1,
        )

    def _extras_out(self, answers: dict[str, Answer]) -> dict[str, Any]:
        out = {}
        for key, q in self._extras.items():
            a = answers[key]
            if a.type == "noul":
                out[key] = {"answer": a.value >= 0.5, "probability": round(a.value, 4)}
            elif a.type == "choice":
                out[key] = {"answer": a.value, "probability": round(a.probabilities.get(a.value, 0.0), 4)}
            else:
                best = max(a.probabilities.items(), key=lambda kv: kv[1])[0] if a.probabilities else None
                out[key] = {"answer": best, "score": round(a.value, 4),
                            "probabilities": {k: round(v, 4) for k, v in a.probabilities.items()}}
        return out

    def close(self):
        self.backend.close()
