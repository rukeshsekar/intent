"""Use-case configuration: everything that changes between use cases lives in one YAML file."""
from __future__ import annotations

from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, Field, field_validator, model_validator


class BackendConfig(BaseModel):
    """Where decisions come from. Jev and Kev speak the same TypeSafe API, so only these fields differ."""
    provider: Literal["jev", "kev", "typesafe-compatible"] = "kev"
    base_url: str | None = None          # None = TypeSafe's hosted API (Jev)
    model: str | None = None             # None = the server's default (jev-latest / kev-latest)
    api_key_env: str = "TYPESAFE_API_KEY"  # env var holding the key; local Kev accepts any key
    timeout_s: float = 120.0


class Intent(BaseModel):
    description: str = ""
    examples: list[str] = Field(default_factory=list)
    min_confidence: float | None = None  # overrides policy.min_confidence for this intent
    children: dict[str, "Intent"] = Field(default_factory=dict)

    @property
    def is_group(self) -> bool:
        return bool(self.children)


class Policy(BaseModel):
    min_confidence: float = 0.5          # below this the result is routed to review / fallback
    min_margin: float = 0.0              # top-1 minus top-2 probability must be at least this
    top_k: int = 3                       # alternatives returned to the caller
    multi_threshold: float = 0.5         # multi-label: an intent is present when its probability >= this
    target_error: float = 0.05           # evaluation: suggest the threshold that keeps errors under this


class InputConfig(BaseModel):
    max_chars: int = 4000                # longer inputs are cut (and flagged); Kev was trained on short states
    context: str | None = None           # static background sent with every message (e.g. what the company sells)


class ExtraQuestion(BaseModel):
    """Additional decisions answered in the same model call (urgency, sentiment, language, ...)."""
    type: Literal["noul", "choice", "score"]
    instructions: str
    options: dict[str, str] | list[str] | None = None

    @model_validator(mode="after")
    def _options_match_type(self):
        if self.type == "choice" and not isinstance(self.options, dict | list):
            raise ValueError("choice questions need options")
        if self.type == "score" and not isinstance(self.options, list):
            raise ValueError("score questions need an ordered list of options")
        return self


class UseCaseConfig(BaseModel):
    name: str
    description: str = ""
    backend: BackendConfig = Field(default_factory=BackendConfig)
    instructions: str = "What is the intent of this message?"
    mode: Literal["single", "multi"] = "single"
    intents: dict[str, Intent]
    fallback_intent: str = "other"
    add_fallback_option: bool = True     # offer the fallback as an option the model can pick
    fallback_description: str = "None of the other options fit, or the message is out of scope"
    # Send intent examples to the model inside each option. Off by default: on Kev-0.8B, quoted examples made the model
    # pick the fallback for any message that did not match an example (0/6 vs 6/6, scripts/ablation.py).
    examples_in_options: bool = False
    policy: Policy = Field(default_factory=Policy)
    input: InputConfig = Field(default_factory=InputConfig)
    extra_questions: dict[str, ExtraQuestion] = Field(default_factory=dict)

    @field_validator("intents", mode="before")
    @classmethod
    def _shorthand(cls, v):
        # allow `billing: "Payments and refunds"` as shorthand for {description: ...}
        def expand(d):
            out = {}
            for k, x in (d or {}).items():
                if isinstance(x, str) or x is None:
                    out[k] = {"description": x or ""}
                else:
                    x = dict(x)
                    if "children" in x:
                        x["children"] = expand(x["children"])
                    out[k] = x
            return out
        return expand(v)

    @model_validator(mode="after")
    def _check(self):
        leaves = self.leaf_intents()
        if len(leaves) < 2:
            raise ValueError("a classifier needs at least two intents")
        if self.fallback_intent in leaves:
            raise ValueError(f"fallback_intent '{self.fallback_intent}' must not also be an intent")
        clash = set(self.extra_questions) & {"intent", "group"}
        if clash:
            raise ValueError(f"extra question names {clash} are reserved")
        return self

    def leaf_intents(self) -> dict[str, Intent]:
        """Every intent the classifier can return, flattened out of any groups."""
        out: dict[str, Intent] = {}
        for name, intent in self.intents.items():
            if intent.is_group:
                out.update(intent.children)
            else:
                out[name] = intent
        return out

    def parent_of(self, leaf: str) -> str | None:
        for name, intent in self.intents.items():
            if leaf in intent.children:
                return name
        return None

    @property
    def hierarchical(self) -> bool:
        return any(i.is_group for i in self.intents.values())

    def labels(self) -> list[str]:
        return [*self.leaf_intents(), self.fallback_intent]


def load_config(path: str | Path) -> UseCaseConfig:
    with open(path, encoding="utf-8") as f:
        return UseCaseConfig.model_validate(yaml.safe_load(f))


def load_config_dir(directory: str | Path) -> dict[str, UseCaseConfig]:
    configs = {}
    for p in sorted(Path(directory).glob("*.y*ml")):
        cfg = load_config(p)
        configs[cfg.name] = cfg
    return configs
