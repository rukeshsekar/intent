"""HTTP service: one endpoint for every use case. Configs are read from a folder; POST /reload picks up edits."""
from __future__ import annotations

import os
import threading

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from .backend import BackendUnavailable
from .config import load_config_dir
from .engine import ClassificationResult, IntentClassifier

CONFIG_DIR = os.environ.get("INTENT_CONFIG_DIR", "configs")

app = FastAPI(title="Intent Classifier", version="0.1.0")
_lock = threading.Lock()
_classifiers: dict[str, IntentClassifier] = {}


def _load():
    new = {name: IntentClassifier(cfg) for name, cfg in load_config_dir(CONFIG_DIR).items()}
    with _lock:
        old = dict(_classifiers)
        _classifiers.clear()
        _classifiers.update(new)
    for c in old.values():
        c.close()
    return list(new)


class ClassifyRequest(BaseModel):
    config: str
    text: str
    context: dict | None = None


@app.on_event("startup")
def _startup():
    _load()


@app.get("/configs")
def configs():
    return {name: {"description": c.config.description, "mode": c.config.mode, "intents": c.config.labels(),
                   "backend": c.backend.name}
            for name, c in _classifiers.items()}


@app.post("/reload")
def reload():
    return {"loaded": _load()}


@app.post("/classify", response_model=ClassificationResult)
def classify(req: ClassifyRequest):
    clf = _classifiers.get(req.config)
    if clf is None:
        raise HTTPException(404, f"unknown config '{req.config}'; known: {sorted(_classifiers)}")
    try:
        return clf.classify(req.text, req.context)
    except BackendUnavailable as e:
        raise HTTPException(503, str(e)) from e
    except Exception as e:  # timeout, bad response, ...
        raise HTTPException(502, f"model backend error: {e}") from e
