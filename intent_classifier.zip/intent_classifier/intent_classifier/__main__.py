"""Command line:

  python -m intent_classifier classify configs/customer_support.yaml "I was charged twice"
  python -m intent_classifier evaluate configs/customer_support.yaml data/customer_support.csv --out runs/cs
  python -m intent_classifier serve --configs configs --port 8100
"""
from __future__ import annotations

import argparse
import json
import os
import sys

from .backend import BackendUnavailable
from .config import load_config
from .engine import IntentClassifier


def main():
    ap = argparse.ArgumentParser(prog="intent_classifier")
    sub = ap.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("classify", help="classify one or more messages")
    c.add_argument("config"); c.add_argument("text", nargs="+")
    c.add_argument("--base-url", help="override the config's backend URL (e.g. switch Kev <-> Jev)")

    e = sub.add_parser("evaluate", help="score a config on a labelled CSV")
    e.add_argument("config"); e.add_argument("data")
    e.add_argument("--out"); e.add_argument("--workers", type=int, default=1)
    e.add_argument("--base-url"); e.add_argument("--limit", type=int)
    e.add_argument("--shuffle-seed", type=int,
                   help="shuffle the order of intents offered to the model (order-sensitivity check)")

    s = sub.add_parser("serve", help="HTTP API over every config in a folder")
    s.add_argument("--configs", default="configs"); s.add_argument("--port", type=int, default=8100)

    a = ap.parse_args()

    if a.cmd == "serve":
        import uvicorn
        os.environ["INTENT_CONFIG_DIR"] = a.configs
        uvicorn.run("intent_classifier.api:app", host="127.0.0.1", port=a.port)
        return

    cfg = load_config(a.config)
    if a.base_url:
        cfg.backend.base_url = a.base_url
    if getattr(a, "shuffle_seed", None) is not None:
        import random
        names = list(cfg.intents)
        random.Random(a.shuffle_seed).shuffle(names)
        cfg.intents = {n: cfg.intents[n] for n in names}
        print(f"option order (seed {a.shuffle_seed}): {names}")
    clf = IntentClassifier(cfg)
    try:
        if a.cmd == "classify":
            for text in a.text:
                print(json.dumps(clf.classify(text).model_dump(), indent=2))
        else:
            from . import evaluate as ev
            if a.limit:
                rows = ev.read_rows(a.data)[: a.limit]
                import csv, tempfile
                tmp = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False, encoding="utf-8", newline="")
                w = csv.DictWriter(tmp, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows); tmp.close()
                a.data = tmp.name
            report = ev.evaluate(clf, a.data, a.out, a.workers)
            ev.print_report(report)
    except BackendUnavailable as e:
        sys.exit(f"error: {e}")
    finally:
        clf.close()


if __name__ == "__main__":
    main()
