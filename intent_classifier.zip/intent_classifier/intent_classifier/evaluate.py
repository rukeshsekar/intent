"""Score a config on labelled data: accuracy, per-intent results, confusion matrix and a threshold table.

CSV columns: `text`, `label` (multi-label: labels joined with `|`; out-of-scope rows use the config's fallback intent).
"""
from __future__ import annotations

import csv
import json
import time
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .engine import ClassificationResult, IntentClassifier

THRESHOLDS = [0.0, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95]


def read_rows(path: str | Path) -> list[dict]:
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [r for r in csv.DictReader(f) if (r.get("text") or "").strip()]
    if not rows or "label" not in rows[0]:
        raise ValueError(f"{path}: expected columns 'text' and 'label'")
    return rows


def run(clf: IntentClassifier, rows: list[dict], workers: int = 1, progress: bool = True) -> list[ClassificationResult]:
    results: list[ClassificationResult | None] = [None] * len(rows)

    def one(i):
        results[i] = clf.classify(rows[i]["text"])
        if progress:
            r = results[i]
            mark = "ok " if r.predicted_intent in rows[i]["label"].split("|") else "ERR"
            print(f"[{i + 1:>3}/{len(rows)}] {mark} {rows[i]['label']:<16} -> {r.predicted_intent:<16} "
                  f"p={r.confidence:.2f} {r.latency_ms:>7.0f} ms", flush=True)

    with ThreadPoolExecutor(max_workers=workers) as pool:
        list(pool.map(one, range(len(rows))))
    return results  # type: ignore[return-value]


def single_label_report(clf: IntentClassifier, rows, results) -> dict:
    cfg = clf.config
    fallback = cfg.fallback_intent
    gold = [r["label"].strip() for r in rows]
    pred = [r.predicted_intent for r in results]
    conf = [r.confidence for r in results]
    n = len(rows)

    correct = [g == p for g, p in zip(gold, pred)]
    labels = sorted(set(gold) | set(pred), key=lambda x: (x == fallback, x))

    per_intent = {}
    for lab in labels:
        tp = sum(g == lab and p == lab for g, p in zip(gold, pred))
        fp = sum(g != lab and p == lab for g, p in zip(gold, pred))
        fn = sum(g == lab and p != lab for g, p in zip(gold, pred))
        prec = tp / (tp + fp) if tp + fp else 0.0
        rec = tp / (tp + fn) if tp + fn else 0.0
        per_intent[lab] = {"support": tp + fn, "precision": round(prec, 3), "recall": round(rec, 3),
                           "f1": round(2 * prec * rec / (prec + rec), 3) if prec + rec else 0.0}

    confusion = defaultdict(Counter)
    for g, p in zip(gold, pred):
        confusion[g][p] += 1

    # threshold table: auto-handle predictions at or above t (and not the fallback), send the rest to review
    table = []
    for t in THRESHOLDS:
        auto = [i for i in range(n) if conf[i] >= t and pred[i] != fallback]
        errors = sum(not correct[i] for i in auto)
        table.append({"threshold": t, "auto_handled": round(len(auto) / n, 3),
                      "error_rate_on_auto": round(errors / len(auto), 3) if auto else 0.0,
                      "wrong_auto_decisions": errors})
    ok = [row for row in table if row["error_rate_on_auto"] <= cfg.policy.target_error and row["auto_handled"] > 0]
    # most automation within the error target; among equal automation, the stricter threshold
    suggestion = max(ok, key=lambda r: (r["auto_handled"], r["threshold"])) if ok else None

    # what the configured policy actually does end to end
    final = [r.intent for r in results]
    auto_now = [i for i in range(n) if not results[i].needs_review]
    return {
        "config": cfg.name, "model": results[0].model if results else "", "examples": n,
        "accuracy": round(sum(correct) / n, 3),
        "macro_f1": round(sum(v["f1"] for v in per_intent.values()) / len(per_intent), 3),
        "current_policy": {
            "min_confidence": cfg.policy.min_confidence,
            "auto_handled": round(len(auto_now) / n, 3),
            "error_rate_on_auto": round(sum(final[i] != gold[i] for i in auto_now) / len(auto_now), 3) if auto_now else 0.0,
        },
        "suggested_threshold": suggestion,
        "threshold_table": table,
        "per_intent": per_intent,
        "confusion": {g: dict(c) for g, c in confusion.items()},
        "latency_ms": {"mean": round(sum(r.latency_ms for r in results) / n, 1),
                       "max": round(max(r.latency_ms for r in results), 1)},
        "truncated_inputs": sum(r.truncated for r in results),
    }


def multi_label_report(clf: IntentClassifier, rows, results) -> dict:
    fallback = clf.config.fallback_intent
    tp = fp = fn = exact = 0
    for row, r in zip(rows, results):
        gold = {x.strip() for x in row["label"].split("|")} - {fallback}
        pred = {a.intent for a in r.intents}
        tp += len(gold & pred); fp += len(pred - gold); fn += len(gold - pred)
        exact += gold == pred
    prec = tp / (tp + fp) if tp + fp else 0.0
    rec = tp / (tp + fn) if tp + fn else 0.0
    n = len(rows)
    return {"config": clf.config.name, "model": results[0].model if results else "", "examples": n,
            "exact_match": round(exact / n, 3), "micro_precision": round(prec, 3), "micro_recall": round(rec, 3),
            "micro_f1": round(2 * prec * rec / (prec + rec), 3) if prec + rec else 0.0,
            "needs_review": round(sum(r.needs_review for r in results) / n, 3),
            "latency_ms": {"mean": round(sum(r.latency_ms for r in results) / n, 1)}}


def evaluate(clf: IntentClassifier, data: str | Path, out_dir: str | Path | None = None, workers: int = 1) -> dict:
    rows = read_rows(data)
    unknown = {l for r in rows for l in r["label"].split("|")} - set(clf.config.labels())
    if unknown:
        raise ValueError(f"labels not in config {clf.config.name}: {sorted(unknown)}")
    t = time.time()
    results = run(clf, rows, workers)
    report = (multi_label_report if clf.config.mode == "multi" else single_label_report)(clf, rows, results)
    report["wall_seconds"] = round(time.time() - t, 1)
    report["option_order"] = list(clf.config.intents)
    if "source" in rows[0] and clf.config.mode == "single":
        # accuracy per labelled set, e.g. held-out test vs silver labels vs drafted questions
        by = defaultdict(lambda: [0, 0])
        for row, r in zip(rows, results):
            by[row["source"]][0] += r.predicted_intent == row["label"].strip()
            by[row["source"]][1] += 1
        report["by_source"] = {s: {"correct": c, "total": n, "accuracy": round(c / n, 3)} for s, (c, n) in by.items()}

    if out_dir:
        out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
        (out / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
        extra_cols = [c for c in rows[0] if c not in ("text", "label")]  # keep ids, sources, ...
        with open(out / "predictions.csv", "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow([*extra_cols, "text", "label", "predicted_intent", "intent", "confidence", "margin",
                        "needs_review", "alternatives", "extras"])
            for row, r in zip(rows, results):
                w.writerow([*(row[c] for c in extra_cols), row["text"], row["label"], r.predicted_intent, r.intent,
                            r.confidence, r.margin, r.needs_review,
                            "; ".join(f"{a.intent}={a.probability}" for a in r.alternatives), json.dumps(r.extras)])
    return report


def print_report(report: dict) -> None:
    print(f"\n=== {report['config']}  ({report['model']}, {report['examples']} examples, {report['wall_seconds']} s) ===")
    if "accuracy" not in report:
        for k in ("exact_match", "micro_precision", "micro_recall", "micro_f1", "needs_review"):
            print(f"{k:>16}: {report[k]}")
        return
    print(f"accuracy {report['accuracy']}   macro F1 {report['macro_f1']}   "
          f"mean latency {report['latency_ms']['mean']} ms")
    for src, v in report.get("by_source", {}).items():
        print(f"  {src:<22} {v['correct']}/{v['total']} = {v['accuracy']:.0%}")
    cp = report["current_policy"]
    print(f"current policy (min_confidence {cp['min_confidence']}): auto-handles {cp['auto_handled']:.0%}, "
          f"error rate on those {cp['error_rate_on_auto']:.0%}")
    print("\nthreshold  auto-handled  error-rate-on-auto")
    for row in report["threshold_table"]:
        print(f"  {row['threshold']:>5.2f}      {row['auto_handled']:>6.0%}         {row['error_rate_on_auto']:>6.0%}")
    s = report["suggested_threshold"]
    print(f"\nsuggested min_confidence: {s['threshold'] if s else 'none meets the target error'}")
    print("\nintent             support  precision  recall   f1")
    for lab, v in report["per_intent"].items():
        print(f"  {lab:<16} {v['support']:>5}    {v['precision']:>6}   {v['recall']:>6}  {v['f1']:>5}")
    print("\nconfusion (gold -> predicted, errors only):")
    for g, preds in report["confusion"].items():
        errs = {p: c for p, c in preds.items() if p != g}
        if errs:
            print(f"  {g:<16} -> {errs}")
