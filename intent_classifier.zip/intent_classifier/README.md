# Intent Classifier

A config-driven intent classifier built on System One decision models: TypeSafe **Jev** (hosted), **Kev** (self-hosted),
or any server that speaks the TypeSafe `/v1/systemone` API. Each use case is one YAML file; the code is the same for all.

```
 text ──► IntentClassifier(config) ──► Choice / Noul questions ──► backend (Jev | Kev)
                     │                                                   │
                     ◄──────────── probabilities + confidence ◄──────────┘
                     ▼
     decision policy (thresholds, fallback, review)  ──►  {intent, confidence, alternatives, needs_review, extras}
```

## Setup

```bash
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt
```

A model backend must be reachable:

- **Kev (local):** run the Kev server (see `../kev`), e.g. on port 8009. Configs point at `http://127.0.0.1:8009`.
- **Jev (hosted):** set `TYPESAFE_API_KEY`, and in the config use `provider: jev` with no `base_url`.

## Usage

```bash
# one message
.venv\Scripts\python -m intent_classifier classify configs/customer_support.yaml "I was charged twice"

# score a config on labelled data (CSV with columns text,label)
.venv\Scripts\python -m intent_classifier evaluate configs/customer_support.yaml data/customer_support.csv --out runs/cs

# HTTP API over every config in configs/
.venv\Scripts\python -m intent_classifier serve --configs configs --port 8100
#   POST /classify  {"config": "customer_support", "text": "..."}
#   GET  /configs   POST /reload
```

From Python:

```python
from intent_classifier import IntentClassifier, load_config

clf = IntentClassifier(load_config("configs/customer_support.yaml"))
r = clf.classify("I was charged twice", context={"channel": "email"})
print(r.intent, r.confidence, r.needs_review, r.extras)
```

## Adding a use case

Copy a file in `configs/` and edit it. The fields:

| Field | Meaning |
|---|---|
| `backend` | `provider`, `base_url`, `model`, `api_key_env`, `timeout_s`. Switching Jev <-> Kev changes only this block. |
| `instructions` | The question the model answers about each message. |
| `mode` | `single` (one intent per message) or `multi` (every intent that applies, one yes/no question each). |
| `intents` | `name: description`, or `{description, examples, min_confidence, children}`. **Descriptions matter most**: the model reads each option as `name: description`. |
| `children` | Makes a two-level taxonomy: the model picks a group, then an intent within it. Use when there are more than ~10-15 intents. |
| `examples_in_options` | Send each intent's `examples` to the model too. Off by default: on Kev-0.8B it pushed answers to the fallback. Test it per model with `scripts/ablation.py`. |
| `fallback_intent` | Returned when the model is unsure or nothing fits (default `other`). `add_fallback_option` also offers it to the model. |
| `policy` | `min_confidence`, `min_margin`, `top_k`, `multi_threshold`, `target_error` (used by `evaluate` to suggest a threshold). |
| `input` | `max_chars` (longer inputs are cut and flagged), `context` (background sent with every message). |
| `extra_questions` | Other decisions answered in the same call: `noul` (yes/no), `choice`, or `score` (ordered options). |

Then build a labelled CSV (a few hundred real messages is a good start), run `evaluate`, and set `min_confidence` from the
threshold table: it shows, for each threshold, how many messages would be handled automatically and how many of those
would be wrong.

## Result

| Field | Meaning |
|---|---|
| `intent` | What to act on: the predicted intent, or the fallback when the policy is not satisfied |
| `predicted_intent` | The model's top answer before the policy |
| `confidence` | Probability of `predicted_intent` (P(group) x P(intent) for hierarchical configs) |
| `margin` | Top-1 minus top-2 probability |
| `needs_review` / `reason` | Whether to send to a personæ, and why |
| `alternatives` | Top-k intents with probabilities |
| `intents` | Multi mode: every intent above threshold |
| `extras` | Answers to `extra_questions` |
| `truncated`, `latency_ms`, `calls`, `model` | Diagnostics |

## Notes

- Keep option order fixed within a config: Kev's README warns that reordering options can change answers.
- Kev's released checkpoints were trained on short inputs (384-1,024 tokens); longer inputs are accepted but untested.
  Jev accepts ~32k tokens.
- Calibration (does 0.8 confidence mean 80% right?) should be checked per use case with `evaluate` before trusting thresholds,
  and re-checked if the model is quantized or fine-tuned.
- Tests: `.venv\Scripts\python -m pytest tests -q` (uses a scripted backend, no model needed).
