"""Which config choice pushes answers to the fallback? Runs a few messages under config variants.

  python scripts/ablation.py configs/customer_support.yaml data/customer_support.csv --rows 0,7,13,19,31,32
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from intent_classifier.config import load_config  # noqa: E402
from intent_classifier.engine import IntentClassifier  # noqa: E402
from intent_classifier.evaluate import read_rows  # noqa: E402


def variants(base):
    def v(**edits):
        c = base.model_copy(deep=True)
        for path, value in edits.items():
            obj = c
            *parents, leaf = path.split("__")
            for p in parents:
                obj = getattr(obj, p)
            setattr(obj, leaf, value)
        return c

    no_examples = base.model_copy(deep=True)
    for i in no_examples.intents.values():
        i.examples = []
    yield "as configured", base
    yield "no background context", v(input__context=None)
    yield "no fallback option", v(add_fallback_option=False)
    yield "no examples", no_examples
    yield "no context + no fallback option", v(input__context=None, add_fallback_option=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("config"); ap.add_argument("data"); ap.add_argument("--rows", default="0,7,13,19,31,32")
    a = ap.parse_args()
    rows = [read_rows(a.data)[int(i)] for i in a.rows.split(",")]
    base = load_config(a.config)
    base.extra_questions = {}  # only the intent question matters here
    for name, cfg in variants(base):
        clf = IntentClassifier(cfg)
        hits = 0
        detail = []
        for r in rows:
            res = clf.classify(r["text"])
            hits += res.predicted_intent == r["label"]
            detail.append(f"{r['label']}->{res.predicted_intent}({res.confidence:.2f})")
        clf.close()
        print(f"{name:<32} {hits}/{len(rows)}   " + "  ".join(detail), flush=True)


if __name__ == "__main__":
    main()
