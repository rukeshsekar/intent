"""Engine and policy tests with a scripted backend: no model or server needed."""
from pathlib import Path

import pytest

from intent_classifier.backend import Answer, Decision
from intent_classifier.config import UseCaseConfig, load_config, load_config_dir
from intent_classifier.engine import IntentClassifier

ROOT = Path(__file__).resolve().parents[1]


class FakeBackend:
    """Answers each question from `script[question_key]`: a dict of probabilities (choice) or a float (noul)."""
    name = "fake"

    def __init__(self, script):
        self.script, self.calls = script, []

    def decide(self, state, questions):
        self.calls.append((state, questions))
        answers = {}
        for key, q in questions.items():
            s = self.script.get(key)
            if q.type == "noul":
                answers[key] = Answer("noul", s if s is not None else 0.1)
            elif q.type == "choice":
                opts = list(q.options) if q.options else []
                probs = s or {o: 1 / len(opts) for o in opts}
                assert set(probs) <= set(opts), f"scripted options {set(probs)} not offered: {opts}"
                answers[key] = Answer("choice", max(probs, key=probs.get), probs, max(probs.values()))
            else:
                probs = s or {str(o): 1 / len(q.options) for o in q.options}
                answers[key] = Answer("score", 1.0, probs, 0.5)
        return Decision(answers, "fake-model", 1.0)

    def close(self):
        pass


def cfg(**over):
    base = {"name": "t", "intents": {"billing": "Money", "bug": "Broken things", "sales": "Buying"}}
    base.update(over)
    return UseCaseConfig.model_validate(base)


def test_confident_answer_is_returned():
    clf = IntentClassifier(cfg(), FakeBackend({"intent": {"billing": 0.9, "bug": 0.05, "sales": 0.03, "other": 0.02}}))
    r = clf.classify("charged twice")
    assert (r.intent, r.predicted_intent, r.needs_review) == ("billing", "billing", False)
    assert r.alternatives[0].intent == "billing" and len(r.alternatives) == 3


def test_low_confidence_goes_to_fallback_and_review():
    clf = IntentClassifier(cfg(), FakeBackend({"intent": {"billing": 0.4, "bug": 0.35, "sales": 0.2, "other": 0.05}}))
    r = clf.classify("hmm")
    assert r.intent == "other" and r.predicted_intent == "billing" and r.needs_review


def test_per_intent_threshold_overrides_global():
    c = cfg(intents={"billing": {"description": "Money", "min_confidence": 0.95}, "bug": "Broken"})
    clf = IntentClassifier(c, FakeBackend({"intent": {"billing": 0.9, "bug": 0.05, "other": 0.05}}))
    assert clf.classify("x").needs_review


def test_model_choosing_fallback_is_flagged():
    clf = IntentClassifier(cfg(), FakeBackend({"intent": {"billing": 0.05, "bug": 0.05, "sales": 0.05, "other": 0.85}}))
    r = clf.classify("hello")
    assert r.intent == "other" and r.needs_review and "fallback" in r.reason


def test_options_carry_descriptions_and_fallback_but_examples_only_on_request():
    intents = {"billing": {"description": "Money", "examples": ["charged twice"]}, "bug": "Broken"}
    fb = FakeBackend({})
    IntentClassifier(cfg(intents=intents), fb).classify("x")
    opts = fb.calls[0][1]["intent"].options
    assert opts["billing"] == "Money" and "other" in opts

    fb = FakeBackend({})
    IntentClassifier(cfg(intents=intents, examples_in_options=True), fb).classify("x")
    assert fb.calls[0][1]["intent"].options["billing"] == 'Money Examples: "charged twice"'


def test_hierarchy_asks_group_then_leaf_and_multiplies_confidence():
    c = cfg(intents={
        "payments": {"description": "Money", "children": {"refund": "Money back", "invoice": "Documents"}},
        "tech": {"description": "Broken", "children": {"crash": "App closes", "slow": "Slow pages"}},
    })
    fb = FakeBackend({"group": {"payments": 0.8, "tech": 0.1, "other": 0.1},
                      "intent": {"refund": 0.9, "invoice": 0.05, "other": 0.05}})
    r = IntentClassifier(c, fb).classify("I want my money back")
    assert r.path == ["payments", "refund"] and r.intent == "refund" and r.calls == 2
    assert r.confidence == pytest.approx(0.72)
    assert set(fb.calls[1][1]["intent"].options) == {"refund", "invoice", "other"}


def test_multi_label_returns_every_intent_above_threshold():
    c = cfg(mode="multi")
    fb = FakeBackend({"intent:billing": 0.92, "intent:bug": 0.88, "intent:sales": 0.05})
    r = IntentClassifier(c, fb).classify("charged twice and the app crashes")
    assert [a.intent for a in r.intents] == ["billing", "bug"] and not r.needs_review


def test_multi_label_nothing_found_goes_to_fallback():
    fb = FakeBackend({"intent:billing": 0.1, "intent:bug": 0.05, "intent:sales": 0.02})
    r = IntentClassifier(cfg(mode="multi"), fb).classify("hi")
    assert r.intent == "other" and r.needs_review


def test_extra_questions_ride_along_in_the_same_call():
    c = cfg(extra_questions={"urgent": {"type": "noul", "instructions": "Urgent?"},
                             "tone": {"type": "choice", "instructions": "Tone?", "options": ["calm", "angry"]}})
    fb = FakeBackend({"urgent": 0.8, "tone": {"calm": 0.2, "angry": 0.8}})
    r = IntentClassifier(c, fb).classify("x")
    assert len(fb.calls) == 1
    assert r.extras["urgent"] == {"answer": True, "probability": 0.8}
    assert r.extras["tone"]["answer"] == "angry"


def test_long_input_is_truncated_and_flagged():
    c = cfg(input={"max_chars": 10})
    fb = FakeBackend({})
    r = IntentClassifier(c, fb).classify("x" * 50)
    assert r.truncated and fb.calls[0][0] == "x" * 10


def test_context_turns_state_into_json():
    c = cfg(input={"context": "We sell shoes"})
    fb = FakeBackend({})
    IntentClassifier(c, fb).classify("hi", {"channel": "email"})
    assert fb.calls[0][0] == {"message": "hi", "background": "We sell shoes", "context": {"channel": "email"}}


def test_config_validation():
    with pytest.raises(ValueError):
        cfg(intents={"only_one": "x"})
    with pytest.raises(ValueError):
        cfg(fallback_intent="billing")


def test_shipped_configs_load():
    configs = load_config_dir(ROOT / "configs")
    assert "customer_support" in configs and len(configs) >= 3
    for c in configs.values():
        assert len(c.labels()) >= 3
